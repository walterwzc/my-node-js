const http = require('http')

const server = http.createServer((request, response) => {
  response.writeHead(200, {'Content-Type': 'text/plain'})
  response.write('hello world~')
  response.end('aa')
})

server.listen(8000, 'localhost', () => {
  console.log('server is running at http://localhost:8000');
})

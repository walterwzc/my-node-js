const self = require('../03-self')
console.log(self(6,7))

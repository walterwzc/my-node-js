console.log('hello')

function add(x, y) {
	return x + y
}
console.log(add(4, 8))

/*window.onload = function() {
  console.log('world')
}*/
